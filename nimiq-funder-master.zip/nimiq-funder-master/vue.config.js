module.exports = {
  baseUrl: '/nimiq-funder/'
}